import os
input_string: str = r"⌶%'⍺⍵_abcdefghijklmnopqrstuvwxyz¯.⍬0123456789⊢$£∆ABCDEFGHIJKLMNOPQRSTUVWXYZ·⍙{}⊣⌷¨⍨[/⌿\⍀<≤=≥>≠∨∧-+÷×?∊⍴~↑↓⍳○*⌈⌊∇∘(⊂⊃∩∪⊥⊤|;,⍱⍲⍒⍋⍉⌽⊖⍟⌹!⍕⍎⍫⍪≡≢"#&´@^`∣:⍷⋄←→⍝)]⎕⍞⍣"

for char in input_string:
    code_point = ord(char)
    folder_name = f"u{code_point:04x}"  # pad to 4 hex digits
    if not os.path.exists(folder_name):
        os.mkdir(folder_name)

# STEP 1: Detect valid 'uXXXX' folders
def is_valid_u_folder(name):
    return (
        os.path.isdir(name)
        and len(name) == 5
        and name.startswith("u")
        and all(c in "0123456789abcdefABCDEF" for c in name[1:])
    )

# STEP 2: Sort folders like Windows (letters before numbers per char)
def custom_sort_key(name):
    def char_order(c):
        if c.isalpha():
            return (0, c.lower())  # Letters first
        elif c.isdigit():
            return (1, c)          # Then digits
        else:
            return (2, c)
    return [char_order(c) for c in name]

# Get original folder names
folders = [name for name in os.listdir() if is_valid_u_folder(name)]
folders.sort(key=custom_sort_key)

# STEP 3: Rename with index prefixes
for i, folder in enumerate(folders):
    new_name = f"{i:03d}__{folder}"
    if not os.path.exists(new_name):
        os.rename(folder, new_name)
        folders[i] = new_name  # update list with new name
    else:
        print(f"Skipping rename, already exists: {new_name}")
        folders[i] = new_name  # still use the new name

# STEP 4: Print final folder names and characters
print("Final sorted folders:")
for folder in folders:
    try:
        code_point = int(folder.split("__")[1][1:], 16)
        char = chr(code_point)
        print(f"{char} -> {folder}")
    except Exception as e:
        print(f"Skipping invalid folder: {folder} ({e})")
