import os
import shutil
import hashlib

# Create output folder if it doesn't exist
output_folder = "sorted"
os.makedirs(output_folder, exist_ok=True)

# Go through each folder that matches '###__uXXXX'
for name in os.listdir():
    if os.path.isdir(name) and "__u" in name:
        try:
            index_part, unicode_part = name.split("__")
            hex_part = unicode_part[1:]  # strip the 'u'
            cleaned_hex = hex_part.lstrip("0") or "0"  # remove leading zeroes, but don't leave it empty
            unicode_prefix = f"u{cleaned_hex}"

            # Loop through all files inside this folder
            folder_path = os.path.join(os.getcwd(), name)
            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)

                if os.path.isfile(file_path):
                    # Read file content to hash it
                    with open(file_path, "rb") as f:
                        file_data = f.read()
                        hash_val = hashlib.sha1(file_data).hexdigest()[:6]  # Short hash

                    ext = os.path.splitext(filename)[1].lower()  # Keep original extension
                    new_filename = f"{unicode_prefix}-{hash_val}{ext}"
                    new_path = os.path.join(output_folder, new_filename)

                    shutil.copy2(file_path, new_path)
                    print(f"Moved: {filename} -> {new_filename}")

        except Exception as e:
            print(f"Skipping {name}: {e}")
